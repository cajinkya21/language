This is a program that expands the hypothetical macroprocessor.
just run cc mp.c and run ./a.out
This will show the output on the stdout
