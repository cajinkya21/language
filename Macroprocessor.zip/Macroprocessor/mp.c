#include <stdio.h>
#include <string.h>
#include <stdlib.h>
int d = 0, e = 0;//definition and expansion flags.
int mntIndex = 0, mdtIndex = 0, fvpNum = 0, fvpIndex = 0, avpNum = 0, avpIndex = 0;
struct MNTstruct{
	char name[100];
	int operands;
	int mdtLine;
}MNT[100];
struct MDTstruct{
	int line;
	char data[100];
}MDT[1000];
struct formalVSpos{
	char formal[100];
	int pos;
}FVP[100][10];
struct actualVSpos{
	char actual[100];
	int pos;
}AVP[100][10];
char *itoa(int num){
	if(num == 0)
		return "0";
	else if(num == 1)
		return "1";
	else if(num == 2)
		return "2";
	else if(num == 3)
		return "3";
	else if(num == 4)
		return "4";
	else if(num == 5)
		return "5";
	else if(num == 6)
		return "6";
	else if(num == 7)
		return "7";
	else
		return "8";
}
char *strrep(char *line, char *search, int loc){
	int i = 0;
	char *newLine, *val;
	newLine = (char *) malloc(100);	
	for(val = strtok(line, " "); val; val = strtok(NULL, " ")){
		if(strcmp(val, search) == 0){
			strcpy(val, itoa(loc));
		}
		if(i != 0)
			strcat(newLine, " ");
		i++;
		strcat(newLine, val);
	}
	return newLine;
}
char *strrepNew(char *line, char *search, char *loc){
	int i = 0;
	char *newLine, *val;
	newLine = (char *) malloc(100);	
	for(val = strtok(line, " "); val; val = strtok(NULL, " ")){
		if(strcmp(val, search) == 0){
			strcpy(val, loc);
		}
		if(i != 0)
			strcat(newLine, " ");
		i++;
		strcat(newLine, val);
	}
	return newLine;
}
char *refineLine(char *line){
	char *retLine, *val;
	retLine = (char *) malloc(100);
	int i;
	strcpy(retLine, line);
	for(val = strtok(line, " "); val; val = strtok(NULL, " ")){
		for(i = 0; i < fvpIndex; i++){
			if(strcmp(val, FVP[fvpNum][i].formal) == 0){
				retLine = strrep(retLine, val, FVP[fvpNum][i].pos);
			}
		}
	}
	return retLine;
}
char *correctLine(char *line){
	char *retLine, *val;
	int i;
	retLine = (char *) malloc(100);
	strcpy(retLine, line);
	for(val = strtok(line, " "); val; val = strtok(NULL, " ")){
		for(i = 0; i < avpIndex; i++){
			if(strcmp(val, itoa(AVP[avpNum][i].pos)) == 0){
				retLine = strrepNew(retLine, val, AVP[avpNum][i].actual);
			}
		}
	}
	return retLine;
}
int process(char *line){
	char *val, oldLine[100];
	int i, x, tokNum = 0, params = 0;
	strcpy(oldLine, line);
	if((d == 0) && (e == 0)){
		if(strcmp(line, "MEND") != 0){
			printf("%s\n", oldLine);//the normal line from source.
		}
	}
	else if((d == 1) && (e == 0)){
		for(val = strtok(line, " "); val; val = strtok(NULL, " ")){//get every literal and process it.
			if(strcmp("MACRO", val) == 0){
				tokNum++;
			}
			else if(tokNum == 1){
				strcpy(MNT[mntIndex].name, val);
				MNT[mntIndex].mdtLine = mdtIndex;
				mntIndex++;
				tokNum++;
			}
			else if(tokNum == 2){//this is an argument
				if(val[strlen(val) - 1] == ','){
					val[strlen(val) - 1] = '\0';
				}
				strcpy(FVP[fvpNum][fvpIndex].formal, val);
				FVP[fvpNum][fvpIndex].pos = params - 2; // #1, #2, #3...#n
				fvpIndex++;
			}
			params++;
		}
		if(tokNum == 2){//means that the line is macro definition line
			MNT[mntIndex - 1].operands = params - 2;
		}
		else{
			MDT[mdtIndex].line = mdtIndex;
			strcpy(MDT[mdtIndex].data, refineLine(oldLine));
			mdtIndex++;
			if(strcmp(oldLine, "MEND") == 0){
				d = 0;
			}
		}
	}
	else if((d == 0) && (e == 1)){
		strcpy(oldLine, line);
		for(val = strtok(line, " "); val; val = strtok(NULL, " ")){//get every literal and process it.
			if(tokNum != 0){//this means that the token is one of the parameters.
				//insert into actual vs positional
				if(val[strlen(val) - 1] == ','){
					val[strlen(val) - 1] = '\0';
				}
				strcpy(AVP[avpNum][avpIndex].actual, val);
				AVP[avpNum][avpIndex].pos = tokNum - 1; // #1, #2, #3...#n
				avpIndex++;
			}
			tokNum++;
		}
		strcpy(line, oldLine);
		
		for(val = strtok(line, " "); val; val = strtok(NULL, " ")){//get every literal and process it.
			for(i = 0; i < mntIndex; i++){
				if(strcmp(MNT[i].name, val) == 0){
					if(tokNum-1 == MNT[i].operands){
						for(x = MNT[i].mdtLine; (strcmp(MDT[x].data, "MEND") != 0); x++){
							printf("%s\n", correctLine(MDT[x].data));//print the value instead of #1, #2, etc
						}
						e = 0;	
					}
				}		
			}
		}
		e = 0;
	}
	return 1;
}
void makeFlags(char *line){//just set/unset the flags if this is macro / mend statement
	char *val, i;
	char oldLine[100];
	strcpy(oldLine, line);
	for (val = strtok(line, " "); val; val = strtok(NULL, " ")){
		if(strcmp(val, "MACRO") == 0)
			d = 1;
		for(i = 0; i < mntIndex; i++){
			if(strcmp(MNT[i].name, val) == 0){
				e = 1;
				break;
			}
		}	
	}
	process(oldLine);//now process the line.
}
int pass1(){
	FILE *fp = fopen("src2.asm", "r");
	char line[100];
	while(fscanf(fp, "%[^\n]\n", line) != EOF){
		makeFlags(line);
	}
	return 1;
}
int main(){
	pass1();
	int i ;
/*	for(i = 0; i < mntIndex; i++){
		printf("%s\t\t%d\t\t%d\n", MNT[i].name, MNT[i].operands, MNT[i].mdtLine);
	}
	for(i = 0; i < mdtIndex; i++){
		printf("%d\t\t%s\n", MDT[i].line, MDT[i].data);
	}
*/
	return 0;
}