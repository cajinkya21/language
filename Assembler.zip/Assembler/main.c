#include <stdio.h>
#include <stdlib.h>
#include <string.h>
FILE *motp, *potp, *srcp, *symtabp, *output;
int symtabIndx = 0, StartAddress = 0, MotIndex = 0;
char tmp[100], cs = 1, ds = 0; //initially code section should be the key section
enum {LABEL, CONSTANT, VARIABLE, UNKNOWN};
enum {DUPLICATELABEL, SYMBOLUNDEFINED, NOENDP, NOERROR};
int errCode = NOERROR;
struct motstruct{
	char name[10];
	int opcode;
	int num_operands;
	int inst_len;
}mot[300];

struct potstruct{
	char psuedo_op[10];
	int num_operands;
}pot[300];

struct srcstruct{
	char label[100];
	char opcode[10];
	char operand[10];
	int line_num;
}src[300];

struct symtabstruct{
	char symbol[20];
	int address;
	int type;
}symtab[300];

void read_mot(){
	motp = fopen("MOT", "r");
	fscanf(motp, "%[^\n]\n",tmp);
	int i = 0;
	while(fscanf(motp, "%s	%d	%d	%d\n", mot[i].name, &mot[i].opcode, &mot[i].num_operands, &mot[i].inst_len) != EOF){
		MotIndex++;
		i++;
	}
	fclose(motp);
}
void read_pot(){
	potp = fopen("POT", "r");
	fscanf(potp, "%[^\n]\n",tmp);
	int i = 0;
	while(fscanf(potp, "%s	%d\n", pot[i].psuedo_op, &pot[i].num_operands) != EOF)
		i++;
	fclose(potp);
}

int contains(char *str1, char *str2){
	char *s1, *s2;
	s1 = str1;
	s2 = str2;			
	while(*s1 != '\0'){
		if(*s1 == *s2){
			s2++;
			if(*s2 == '\0')
				return 1;
		}
		else
			s2 = str2;
		s1++;
	}
	return 0;
}
int existsInSymtab(char *val){
	int i;
	for(i = 0; i < symtabIndx; i++){
		if((strcmp(val, symtab[i].symbol) == 0)){
			return 1;
		}
	}
	return 0;
}
int fixSymtab(char *val, int addr){//if the symbol address is -1, then fix it.
	int i;
	for(i = 0; i < symtabIndx; i++){
		if((strcmp(val, symtab[i].symbol) == 0) && (symtab[i].address == -1)){
			symtab[i].address = addr;
			return 1;//symtab is fixed
		}
	}
	return 0;
}
void process_cs(char line[100], int len){//processes code segment and creates entries in symtab & enters data into srcstruct
	char *val, num = 0;
	val = strtok(line, ";"); //remove the comments
	for (val = strtok(line, " "); val; val = strtok(NULL, " ")){
		if(contains(val, ":")){
			val[strlen(val) - 1] = '\0';//remove : of label
			strcpy(src[len].label, val);
			if(!existsInSymtab(val)){
				strcpy(symtab[symtabIndx].symbol, val);
				symtab[symtabIndx].address = len + StartAddress;
				symtab[symtabIndx].type = LABEL;
				symtabIndx++;
			}
			else{
				if(!fixSymtab(val, len + StartAddress)){
					errCode = DUPLICATELABEL;
					return;
				}
			}
			num--;
		}
		if(num == 0){
			strcpy(src[len].opcode, val);
		}
		else if(num == 1){
			strcpy(src[len].operand, val);	
			if(!existsInSymtab(val)){
				strcpy(symtab[symtabIndx].symbol, val);
				symtab[symtabIndx].address = -1;//operands will be given address from data section.
				symtab[symtabIndx].type = UNKNOWN;
				symtabIndx++;
			}
		}
		num++;
	}

}
void process_ds(char line[100], int len){//processes data segment and fills entries in symtab
	char *val, num = 0, i, m, enjy = 0;
	val = strtok(line, ";"); //remove the comments
	for (val = strtok(line, " "); val; val = strtok(NULL, " ")){
		if(num == 0){
			for(i = 0; i < symtabIndx; i++){
				if(strcmp(val, symtab[i].symbol) == 0){
					symtab[i].address = len + StartAddress;
					break;//this means i is the index of the symbol ka location.
				}
			}
			num++;
		}
		else if(num == 1){
			if(strcmp(val, "CONST") == 0){
				symtab[i].type = CONSTANT;
			}
			else if(strcmp(val, "DB") == 0){
				symtab[i].type = VARIABLE;
			}
			num++;
		}
		else{
			if(strcmp(val, "?") == 0){
				symtab[i].address = len + StartAddress;
			}
			else{
				for(m = 0; val[m] != '\0'; m++){
					enjy = (enjy * 10) + (val[m] - 48);
				}
				symtab[i].address = enjy;
				enjy = 0;
			}
		}
	}
}
int checkError(int line){
	if(errCode == NOERROR)
		return 0;
	else if(errCode == DUPLICATELABEL){
		printf("ERROR: On line number %d : Duplicate label is used, errorcode: %d. Stopping\n", line, DUPLICATELABEL);
		return 1;
	}
	else if(errCode == SYMBOLUNDEFINED){
		printf("ERROR: On line number %d : Symbol being refered is undefined, errorcode: %d. Stopping\n", line, SYMBOLUNDEFINED);
		return 1;
	}
	else if(errCode == NOENDP){
		printf("ERROR: On line number %d : ENDP is not in the program, errorcode: %d. Stopping\n", line, NOENDP);
		return 1;
	}
	else
		return 0;
}
void pass1(){//process source file and create symtab & optab.
	srcp = fopen("src.asm", "r");
	int i = 0, j, m = 0;
	while(fscanf(srcp, "%[^\n]\n", tmp) != EOF){
		src[i].line_num = i + StartAddress; //total number of lines of code
		if(contains(tmp, "START") == 1){
			while(tmp[m] != ' '){
				m++;
			}
			m++;
			while(tmp[m] != '\0'){
				StartAddress = (StartAddress * 10) + (tmp[m] - 48);
				m++;
			}
			continue;
		}
		if(cs){
			process_cs(tmp, i); //now process the code segment code
			if(strcmp(tmp, "ENDP") == 0){
				cs = 0;
				ds = 1;
			}
		}
		else if(ds){
			process_ds(tmp, i); //now process the data segment
		}
		if(checkError(i + 1)){
			return;
		}

		i++;
	}
	fclose(srcp); //here, we have read the complete source code section
	//now process the source code to build a symtab
/*	for(j = 0; j < i; j++){
    	printf("%d      %s      %s      %s\n", src[j].line_num, src[j].label,src[j].opcode,src[j].operand);
	}

	for(j = 0; j < symtabIndx; j++){
    	printf("%s\t\t%d\t\t%d\n", symtab[j].symbol, symtab[j].address,symtab[j].type);
	}*/
}
int seekMOT(char *data){
	int i;
	for(i = 0; i < MotIndex; i++){
		if(strcmp(mot[i].name, data) == 0){
			errCode = NOERROR;
			return mot[i].opcode;
		}
	}
	errCode = SYMBOLUNDEFINED;
	return -1;
}
int seekSYMTAB(char *data){
	int i;
	for(i = 0; i < symtabIndx; i++){
		if(strcmp(symtab[i].symbol, data) == 0){
			errCode = NOERROR;
			return symtab[i].address;
		}
	}
	errCode = SYMBOLUNDEFINED;
	return -1;
}
int pass2(){
	//here, get the src struct, mot, pot & symtab. Then simply generate the output file!
	int i, skmot, sksym;
	for(i = 0; (strcmp(src[i].opcode, "ENDP") != 0); i++){
		if(strcmp(src[i].opcode, "STOP") == 0){
			printf("%04d\t\t%04d\n", src[i].line_num, seekMOT(src[i].opcode));
			continue;
		}
		skmot = seekMOT(src[i].opcode);
		sksym = seekSYMTAB(src[i].operand);
		if(skmot == -1){
			printf("%s", src[i].opcode);
			return checkError(i + 1);
		}
		if(sksym == -1){
			printf("%s", src[i].operand);
			return checkError(i + 1);
		}
		printf("%04d\t\t%04d\t\t%04d\n", src[i].line_num, skmot, sksym);
	}
	return 0;
}
int main(){
	system("./lineit src.asm srcnew.asm"); //number the line
	read_mot();
	read_pot();
	pass1();
	pass2();
	return 0;
}