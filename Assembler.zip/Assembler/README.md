This is the code that Assembles a hypothetical .asm code.
just run the file with cc main.c
and then see the output on the stdout itself.
